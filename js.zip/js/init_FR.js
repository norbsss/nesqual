ct_$('html').ultimateGDPR({
    popup_style: {
        position: 'bottom-panel', // bottom-left, bottom-right, bottom-panel, top-left, top-right, top-panel
        distance: '20px', // distance betwen popup and window border
        box_style: 'classic', // classic, modern
        box_shape: 'rounded', // rounded, squared
        background_color: '#fff584', // color in hex
        text_color: '#542d04', // color in hex
        button_shape: 'rounded', // squared, rounded
        button_color: '#e1e1e1', // color in hex
        button_size: 'normal', // normal, large
        box_skin: 'skin-dark-theme', // skin-default-theme, skin-dark-theme, skin-light-theme
        gear_icon_position: 'bottom-left', // top-left, top-center, top-right, center-left, center-right, bottom-left, bottom-center, bottom-right
        gear_icon_color: '#6a8ee7', //color in hex
    },
    popup_options: {
        parent_container: 'body', // append plugin html to this element selector
        always_show: false, // true, false, when true popup is displayed always even when consent is given
        gear_display: true, // true, false when true displays icon with cookie settings
        popup_title: 'Cookies', // title for popup
        popup_text: 'Cookies Pour que ce site fonctionne correctement, nous plaçons parfois de petits fichiers de données appelés cookies sur votre appareil. La plupart des grands sites le font aussi.', // text for popup
        accept_button_text: 'Acceptez', // string, text for accept button
        read_button_text: 'Lire la suite', // string, text for read more button
        read_more_link: '', // string, link to the Read More page
        advenced_button_text: 'Modifier les paramètres', // string, text for advenced button
        grouped_popup: true, // true, false, when true cookies are grouped
        default_group: 'group_2', // string: name, select group that will be selected by default
        content_before_slider: '<h2>Paramètres de confidentialité</h2><div class="ct-ultimate-gdpr-cookie-modal-desc"><p>Décidez quels cookies vous souhaitez autoriser.</p><p>Vous pouvez modifier ces paramètres à tout moment. Cependant, cela peut entraîner certaines fonctions ne sont plus disponibles. Pour plus d\'informations sur la suppression des cookies, veuillez consulter la fonction d\'aide de votre navigateur.</p> <span>En savoir plus sur les cookies que nous utilisons.</span></div><h3>Avec le curseur, vous pouvez activer ou désactiver différents types de cookies:</h3>',
        // string: this content will be displayed before cookies slider, html tags alowed
        accepted_text: 'Ce site web va:',
        declined_text: "Ce site web ne va pas:",
        save_btn: 'Sauvegarder et fermer', // string, text for modal close btn
        prevent_cookies_on_document_write:  false, // prevent cookies on document write when there is no agreement for cookies
        check_country: false,
        countries_prefixes: ['AT', 'BE', 'BG', 'HR', 'CY', 'CZ', 'DK', 'EE', 'FI', 'FR', 'DE', 'GR', 'HU', 'IE', 'IT', 'LV', 'LT', 'LU', 'MT', 'NL', 'PL', 'PT', 'RO', 'SK', 'SI', 'ES', 'SE', 'GB'],
        cookies_expire_time: 30, // set number of days, you can use 0 for session only or 'unlimited'
        cookies_path: '/', // sets custom path use / for global, '/your_path' for custom path or 'current' for current path
        reset_link_selector: '.ct-uGdpr-reset',
        first_party_cookies_whitelist: [],
        third_party_cookies_whitelist: [],
        cookies_groups_design: 'skin-1', // skin-1, skin-2, skin-3
        assets_path : '/assets', // absolute path to directory with assets
        video_blocked: 'Ce contenu est bloqué!',
        iframe_blocked: false,
        cookie_popup_close_color:'#fff',
        close_popup_text: '', // Close popup text (If empty, button X(close) will display. If not, it will display the text)
        cookies_groups: {
            group_1: {
                name: 'Essentiel', // string: name
                enable: true, // true, false, you can disable this group by using false
                icon: 'fas fa-check', // string icon class from font-awesome see -> http://fontawesome.io
                list: ['Se souvenir de votre paramètre d\'autorisation de cookie', 'Autoriser les cookies de session', 'Rassemblez les informations que vous avez saisies dans un formulaire de contact, un bulletin d\'information et d\'autres formulaires sur toutes les pages', 'Gardez une trace de ce que vous entrez dans votre panier', 'Authentifier que vous êtes connecté à votre compte d\'utilisateur', 'Se souvenir de la version linguistique que vous avez sélectionnée'], // array list of options
                blocked_url: [], // array list of url blocked scripts
                local_cookies_name: [], // array, list of local cookies names
            },
            group_2: {
                name: 'Fonctionnalité', // string: name
                enable: true, // true, false, you can disable this group by using false
                icon: 'fas fa-cog', // string icon class from font-awesome see -> http://fontawesome.io
                list: ['Mémoriser les paramètres des médias sociaux', 'Se souvenir de la région et du pays sélectionnés',],
                blocked_url: [], // array list of url blocked scripts
                local_cookies_name: [], // array, list of local cookies names
            },
            group_3: {
                name: 'Analytique', // string: name
                enable: true, // true, false, you can disable this group by using false
                icon: 'fas fa-chart-bar', // string icon class from font-awesome see -> http://fontawesome.io
                list: ['Gardez une trace de vos pages visitées et des interactions prises', 'Suivez votre localisation et votre région en fonction de votre numéro IP', 'Gardez une trace du temps passé sur chaque page', 'Augmenter la qualité des données des fonctions statistiques'],
                blocked_url: [], // array list of url blocked scripts
                local_cookies_name: [], // array, list of local cookies names
            },
            group_4: {
                name: 'La publicité', // string: name
                enable: true, // true, false, you can disable this group by using false
                icon: 'fas fa-exchange-alt', // string icon class from font-awesome see -> http://fontawesome.io
                list: ['Utiliser les informations pour la publicité sur mesure avec des tiers', 'Vous permettre de vous connecter à des sites sociaux', 'Identifiez le périphérique que vous utilisez', 'Recueillir des informations personnellement identifiables telles que le nom et l\'emplacement'],
                blocked_url: [], // array list of url blocked scripts
                local_cookies_name: [], // array, list of local cookies names
            },
        },
    },
    age_popup_style: {
        position: 'top-panel', // bottom-left, bottom-right, bottom-panel, top-left, top-right, top-panel
        distance: '20px', // distance between popup and window border
        box_style: 'classic', // classic, modern
        box_shape: 'rounded', // rounded, squared
        background_color: '#fff584', // color in hex
        text_color: '#542d04', // color in hex
        button_shape: 'rounded', // squared, rounded
        button_color: '#e1e1e1', // color in hex
        box_skin: 'skin-dark-theme', // skin-default-theme, skin-dark-theme, skin-light-theme
    },
    age_popup_options: {
        parent_container: 'body', // append plugin html to this element selector
        always_show: false, // true, false, when true popup is displayed always even when consent is given
        popup_title: 'Age verification', // title for popup
        popup_text: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation.', // text for popup
        age_limit: 13, // age limit to enter
        assets_path : 'assets', // absolute path to directory with assets
        disable_popup: false, // true/false, when true popup will be disabled and hidden on the website
    },
    forms: {
        prevent_forms_send: false, // true, false, when enabled forms get checkbox with info that need to be checked for form send
        prevent_forms_text: 'I consent to the storage of my data according to the Privacy Policy', // string: information for checkbox info
        prevent_forms_exclude: [], // array of selectors (classes, id), this forms will be excluded from prevent
    },
    configure_mode: {
        on: false,
        parametr: '?configure123456',
        dependencies: ['assets/css/ct-ultimate-gdpr.min.css', 'https://use.fontawesome.com/releases/v5.0.13/css/all.css'],
        debug: false, // bool: true false, debug mode on/off (showing all 3rd party cookies urls, blockes urls names of all local cookies and names of blocked local cookies )
    }
});