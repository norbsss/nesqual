ct_$('html').ultimateGDPR({
    popup_style: {
        position: 'bottom-panel', // bottom-left, bottom-right, bottom-panel, top-left, top-right, top-panel
        distance: '20px', // distance betwen popup and window border
        box_style: 'classic', // classic, modern
        box_shape: 'rounded', // rounded, squared
        background_color: '#fff584', // color in hex
        text_color: '#542d04', // color in hex
        button_shape: 'rounded', // squared, rounded
        button_color: '#e1e1e1', // color in hex
        button_size: 'normal', // normal, large
        box_skin: 'skin-dark-theme', // skin-default-theme, skin-dark-theme, skin-light-theme
        gear_icon_position: 'bottom-left', // top-left, top-center, top-right, center-left, center-right, bottom-left, bottom-center, bottom-right
        gear_icon_color: '#6a8ee7', //color in hex
    },
    popup_options: {
        parent_container: 'body', // append plugin html to this element selector
        always_show: false, // true, false, when true popup is displayed always even when consent is given
        gear_display: true, // true, false when true displays icon with cookie settings
        popup_title: 'Cookies', // title for popup
        popup_text: 'Soubory cookie Chcete-li, aby tato stránka fungovala správně, v zařízení někdy umístíme malé soubory dat s názvem soubory cookie. Většina velkých webových stránek to také dělá.', // text for popup
        accept_button_text: 'Akceptovat', // string, text for accept button
        read_button_text: 'Přečtěte si více', // string, text for read more button
        read_more_link: '', // string, link to the Read More page
        advenced_button_text: 'Změnit nastavení', // string, text for advenced button
        grouped_popup: true, // true, false, when true cookies are grouped
        default_group: 'group_2', // string: name, select group that will be selected by default
        content_before_slider: '<h2>Nastavení ochrany osobních údajů</h2><div class="ct-ultimate-gdpr-cookie-modal-desc"><p>Rozhodněte se, které soubory cookie chcete povolit.</p><p>Tyto nastavení můžete kdykoli změnit. To však může vést k tomu, že některé funkce již nejsou k dispozici. Informace o mazání souborů cookie naleznete v nápovědě prohlížeče.</p> <span>Další informace o cookies, které používáme.</span></div><h3>Pomocí posuvníku můžete povolit nebo zakázat různé typy souborů cookie:</h3>',
        // string: this content will be displayed before cookies slider, html tags alowed
        accepted_text: 'Tyto webové stránky budou:',
        declined_text: "Tyto webové stránky nebudou:",
        save_btn: 'Uložit a zavřít', // string, text for modal close btn
        prevent_cookies_on_document_write: false, // prevent cookies on document write when there is no agreement for cookies
        check_country: false,
        countries_prefixes: ['AT', 'BE', 'BG', 'HR', 'CY', 'CZ', 'DK', 'EE', 'FI', 'FR', 'DE', 'GR', 'HU', 'IE', 'IT', 'LV', 'LT', 'LU', 'MT', 'NL', 'PL', 'PT', 'RO', 'SK', 'SI', 'ES', 'SE', 'GB'],
        cookies_expire_time: 30, // set number of days, you can use 0 for session only or 'unlimited'
        cookies_path: '/', // sets custom path use / for global, '/your_path' for custom path or 'current' for current path
        reset_link_selector: '.ct-uGdpr-reset',
        first_party_cookies_whitelist: [],
        third_party_cookies_whitelist: [],
        cookies_groups_design: 'skin-1', // skin-1, skin-2, skin-3
        assets_path : '/assets', // absolute path to directory with assets
        video_blocked: 'Tento obsah je blokován!',
        iframe_blocked: false,
        cookie_popup_close_color:'#fff',
        close_popup_text: '', // Close popup text (If empty, button X(close) will display. If not, it will display the text)
        cookies_groups: {
            group_1: {
                name: 'Nezbytný', // string: name
                enable: true, // true, false, you can disable this group by using false
                icon: 'fas fa-check', // string icon class from font-awesome see -> http://fontawesome.io
                list: ['Nezapomeňte nastavení povolení cookie', 'Povolit cookies relací', 'Shromažďujte informace, které zadáváte do kontaktních formulářů, zpravodaje a dalších formulářů na všech stránkách', 'Sledujte, co zadáváte v nákupním košíku', 'Ověřte, zda jste přihlášeni do uživatelského účtu', 'Zvolte si jazykovou verzi, kterou jste vybrali'], // array list of options
                blocked_url: [], // array list of url blocked scripts
                local_cookies_name: [], // array, list of local cookies names
            },
            group_2: {
                name: 'Funkčnost', // string: name
                enable: true, // true, false, you can disable this group by using false
                icon: 'fas fa-cog', // string icon class from font-awesome see -> http://fontawesome.io
                list: ['Zapamatujte si nastavení sociálních médií', 'Zapamatujte si vybraný region a zemi',],
                blocked_url: [], // array list of url blocked scripts
                local_cookies_name: [], // array, list of local cookies names
            },
            group_3: {
                name: 'Analytics', // string: name
                enable: true, // true, false, you can disable this group by using false
                icon: 'fas fa-chart-bar', // string icon class from font-awesome see -> http://fontawesome.io
                list: ['Sledujte navštívené stránky a proveďte interakci', 'Sledujte svou polohu a oblast podle vašeho IP čísla', 'Sledujte čas strávený na každé stránce', 'Zvyšte kvalitu dat statistických funkcí'],
                blocked_url: [], // array list of url blocked scripts
                local_cookies_name: [], // array, list of local cookies names
            },
            group_4: {
                name: 'Reklamní', // string: name
                enable: true, // true, false, you can disable this group by using false
                icon: 'fas fa-exchange-alt', // string icon class from font-awesome see -> http://fontawesome.io
                list: ['Použijte informace pro inzerci na míru s třetími stranami', 'Umožňuje připojení k sociálním webům', 'Identifikujte zařízení, které používáte', 'Shromažďování osobně identifikovatelných informací, jako je jméno a místo'],
                blocked_url: [], // array list of url blocked scripts
                local_cookies_name: [], // array, list of local cookies names
            },
        },
    },
    age_popup_style: {
        position: 'top-panel', // bottom-left, bottom-right, bottom-panel, top-left, top-right, top-panel
        distance: '20px', // distance between popup and window border
        box_style: 'classic', // classic, modern
        box_shape: 'rounded', // rounded, squared
        background_color: '#fff584', // color in hex
        text_color: '#542d04', // color in hex
        button_shape: 'rounded', // squared, rounded
        button_color: '#e1e1e1', // color in hex
        box_skin: 'skin-dark-theme', // skin-default-theme, skin-dark-theme, skin-light-theme
    },
    age_popup_options: {
        parent_container: 'body', // append plugin html to this element selector
        always_show: false, // true, false, when true popup is displayed always even when consent is given
        popup_title: 'Age verification', // title for popup
        popup_text: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation.', // text for popup
        age_limit: 13, // age limit to enter
        assets_path : 'assets', // absolute path to directory with assets
        disable_popup: false, // true/false, when true popup will be disabled and hidden on the website
    },
    forms: {
        prevent_forms_send: false, // true, false, when enabled forms get checkbox with info that need to be checked for form send
        prevent_forms_text: 'I consent to the storage of my data according to the Privacy Policy', // string: information for checkbox info
        prevent_forms_exclude: [], // array of selectors (classes, id), this forms will be excluded from prevent
    },
    configure_mode: {
        on: false,
        parametr: '?configure123456',
        dependencies: [ 'assets/css/ct-ultimate-gdpr.min.css', 'https://use.fontawesome.com/releases/v5.0.13/css/all.css'],
        debug: false, // bool: true false, debug mode on/off (showing all 3rd party cookies urls, blockes urls names of all local cookies and names of blocked local cookies )
    }
});