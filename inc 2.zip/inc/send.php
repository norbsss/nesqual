<?php
// Get form data
$name = $_POST['name'];
$email = $_POST['email'];
$phone_number = $_POST['phone_number'];
$subject = $_POST['subject'];
$website = $_POST['website'];
$message = $_POST['message'];

// Email recipient and subject
$recipient = "support@nesqualtech.com";
$email_subject = "New form submission";

// Email headers
$headers = "From: $name <$email>\r\n";
$headers .= "Reply-To: $email\r\n";
$headers .= "Content-Type: text/html; charset=UTF-8\r\n";

// Email body
$email_body = "
<html>
<head>
  <title>New form submission</title>
</head>
<body>
  <p><strong>Name:</strong> $name</p>
  <p><strong>Email:</strong> $email</p>
  <p><strong>Phone Number:</strong> $phone_number</p>
  <p><strong>Subject:</strong> $subject</p>
  <p><strong>Website:</strong> $website</p>
  <p><strong>Message:</strong> $message</p>
</body>
</html>
";

// Send email
if (mail($recipient, $email_subject, $email_body, $headers)) {
  echo "Thank you for your message!";
} else {
  echo "Error sending message. Please try again.";
}
?>
