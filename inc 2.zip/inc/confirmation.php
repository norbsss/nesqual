    $mail -> Send();
	    echo "<div class='inner success'><p class='success'>Thanks for contacting us. We will contact you as soon as possible!</p></div>";
}
    catch (Exception $e) {
	    echo "<div class='inner error'><p class='error'>Message could not be sent. Mailer Error: {$mail->ErrorInfo}</p></div>";
}