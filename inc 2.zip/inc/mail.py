from flask import Flask, render_template, request
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/submit', methods=['POST'])
def submit():
    # Get the form data
    name = request.form['name']
    email = request.form['email']
    phone_number = request.form['phone_number']
    services_needed = request.form['services_needed']
    subject = request.form['subject']
    website = request.form['website']
    message = request.form['message']

    # Set the email sender and recipient
    sender_email = "vaduva.nrb21@gmail.com"
    recipient_email = "support@nesqualtech.com"

    # Set the email subject
    email_subject = "New form submission"

    # Create the email message
    message_body = f"Name: {name}\nEmail: {email}\nPhone Number: {phone_number}\nServices Needed: {services_needed}\nSubject: {subject}\nWebsite: {website}\nMessage: {message}"
    email_message = MIMEMultipart()
    email_message['From'] = sender_email
    email_message['To'] = recipient_email
    email_message['Subject'] = email_subject
    email_message.attach(MIMEText(message_body, 'plain'))

    # Send the email using SMTP
    smtp_server = smtplib.SMTP('smtp.gmail.com', 587)
    smtp_server.starttls()
    smtp_server.login(sender_email, 'gauuqtzluimxskga')
    smtp_server.sendmail(sender_email, recipient_email, email_message.as_string())
    smtp_server.quit()

    return 'Thank you for your message!'

if __name__ == '__main__':
    app.run(debug=True)
