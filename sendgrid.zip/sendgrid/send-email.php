<?php
require 'vendor/autoload.php'; // Load the SendGrid PHP library

// Get the form data
$name = $_POST['name'];
$email = $_POST['email'];
$phone_number = $_POST['phone_number'];
$subject = $_POST['subject'];
$website = $_POST['website'];
$message = $_POST['message'];

// Set up the email
$email = new \SendGrid\Mail\Mail();
$email->setFrom($email);
$email->setSubject($subject);
$email->addTo('support@nesqualtech.com'); // Replace with your email address
$email->addContent("text/plain", "Name: $name\nEmail: $email\nPhone Number: $phone_number\nSubject: $subject\nWebsite: $website\nMessage:\n$message");

// Send the email
$sendgrid = new \SendGrid(getenv('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')); // Replace with your SendGrid API key
try {
    $response = $sendgrid->send($email);
    if ($response->statusCode() == 202) {
        echo 'Thank you for your message!';
    } else {
        echo 'There was an error sending your message. Please try again later.';
    }
} catch (Exception $e) {
    echo 'There was an error sending your message. Please try again later.';
}
?>